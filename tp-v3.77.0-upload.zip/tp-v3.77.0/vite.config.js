import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
export default defineConfig({
  plugins: [react()],
  build: { target: ['es2019','safari13'], assetsInlineLimit: 100000000, cssCodeSplit: false, chunkSizeWarningLimit: 100000 },
})
